#ifndef __VERSION_H
#define __VERSION_H

extern char *version_string;
extern char *program_name; 
extern char *author_name;
extern char *email_address; 
extern char *copyright;

#endif/*__VERSION_H*/
